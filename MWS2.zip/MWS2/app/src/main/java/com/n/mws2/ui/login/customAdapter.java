package com.n.mws2.ui.login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.n.mws2.R;

import java.util.ArrayList;

public class customAdapter extends ArrayAdapter<listItem> implements View.OnClickListener {

    private ArrayList<listItem> listSet;
    Context mContext;
    int i = 1;

    private static class ViewHolder {
        TextView title;
        TextView subtitle;
        Button button;
    }

    public customAdapter(ArrayList<listItem> data, Context context) {
        super(context, R.layout.listadapter, data);
        this.listSet = data;

    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        final listItem items = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        final ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.listadapter, parent, false);
            viewHolder.title = (TextView) convertView.findViewById(R.id.firstLine);
            viewHolder.subtitle = (TextView) convertView.findViewById(R.id.secondLine);
            viewHolder.button = (Button) convertView.findViewById(R.id.button);

            result = convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }


        viewHolder.title.setText(items.getTitle());
        viewHolder.subtitle.setText(items.getSubtitle());


        viewHolder.button.setText("Accept");


        viewHolder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!items.isAccepted()) {
                    if(items.getTitle().equals("Changi Fire Station to Changi General Hosp")){
                        mapActivity.getInstance().changeRout3();
                    } else{
                        mapActivity.getInstance().changeRoute();
                    }
                    viewHolder.button.setText("Complete Request");

                    items.setAccepted(true);
                } else {
                    viewHolder.button.setText("Completed");
                   mapActivity.getInstance().changeRoute2();
                    items.setCompleted(true);
                    viewHolder.button.setEnabled(false);
                }
            }
        });

        // Return the completed view to render on screen
        return convertView;
    }
}
