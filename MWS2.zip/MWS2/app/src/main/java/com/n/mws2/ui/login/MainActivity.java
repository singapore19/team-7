package com.n.mws2.ui.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import com.n.mws2.R;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    private TextView tasks;
    private int numbertask;
    private String taskoutput;

    public static int getRandomNumberInts(int min, int max){
        Random random = new Random();
        return random.ints(min,(max+1)).findFirst().getAsInt();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tasks = (TextView)findViewById(R.id.textView2);

        Button b = (Button)findViewById(R.id.button2);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent x = new Intent(getApplicationContext(), mapActivity.class);
                startActivity(x);
            }
        });


        CalendarView calendarView = findViewById(R.id.calendarView);
        if (calendarView != null) {
            calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                @Override
                public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                    // Note that months are indexed from 0. So, 0 means January, 1 means february, 2 means march etc.
                    String msg = "Selected date is " + dayOfMonth + "/" + (month + 1) + "/" + year;
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();

                    if (dayOfMonth < 4) {

                        tasks.setText("TASKS AVAILABLE: 0");
                    }

                    else if (dayOfMonth > 4) {
                        numbertask = getRandomNumberInts(1,6);
                        taskoutput = "TASKS AVAILABLE: " + numbertask;
                        tasks.setText(taskoutput);

                    }

                    else {
                        tasks.setText("TASKS AVAILABLE: 3");
                    }



                }
            });
        }
    }
}
