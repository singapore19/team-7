package com.n.mws2.ui.login;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
