package com.n.mws2.ui.login;

public class listItem {

    private String title;
    private String subtitle;
    private boolean accepted;
    private boolean completed;

    public listItem(String title, String subtitle, boolean accepted, boolean completed) {
        this.title = title;
        this.subtitle = subtitle;
        this.accepted = accepted;
        this.completed = completed;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public boolean isAccepted() {
        return accepted;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}
